<?php
	
   session_start();
   $_SESSION['my']=$user;
   

?>