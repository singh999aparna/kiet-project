<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="../event management/bootstrap-3.3.6-dist/css/bootstrap.css" rel="stylesheet" />
<title>Untitled Document</title>
<style>
.i
{
	margin-left:100px;
	transition:ease-in;
	transition-delay:2s;
}
.i:hover
{
	animation:ease-out;
	animation-delay:2s;
	width:100%;
	height:100%;
}
</style>
</head>

<body>
<div class="container">
<img src="../event management/img/cock/9b1869390a5c9166ba810faf257c5a0a--christmas-cocktail-party-christmas-cocktails.jpg" class="i" />
</div>
</body>
</html>