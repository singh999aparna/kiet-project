<?php 
	include"Home.php";
?>
<br/><br/><br/>
<div class="container-fluid"  style="width:40%; min-height:350px"><h1 style="color:#006; font-family:'MS Serif', 'New York', serif; font-size:36px"><center><span class="glyphicon glyphicon-check"></span> Successfully Logged Out...</center></h1>
        <br/>
        <h4 style="color:#009; font-family:'MS Serif', 'New York', serif">Thanks for using Online Event Organizer...</h4>
             <img src="img/images.png" class="col-sm-3 img img-responsive" style="width:100%; height:200px;"/><br/>
        </div>
   <div class="container-fluid"  style="width:40%; height:120px">
	    <center><button type="button" class="form-control btn btn-xs btn-success" style="width:400px; height:45px;font-size:22px"><span class="glyphicon glyphicon-book"></span><a href="login.php" style="text-decoration:none; color:#006;"> Continue to Login</a></button></center>
         
                <h5 style="color:#000"><center>--------------Or--------------</center></h5>       
                <a href="Signup.php"><center>Create account</center></a>

        </div>
   <?php include"footer.php"; ?>
</body>
</html>					
