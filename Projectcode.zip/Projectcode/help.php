<?php include"home.php"; ?>
<br/><br/>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Help Regarding</title>
</head>

<body background="img/ccc.jpg">
<div class="container container-fluid">
   <h1 style="color:#03F; text-shadow:#900 1px 1px 1px;"><center><u> "Helping Section of Online Event Organizer"</u></center></h1>
   <h4><a href="slider.php" style="text-decoration:none; color:#FFF">Home </a> <img src="img/back-ar.gif"/><span style="color:#FFF">  Help</span> </h4>
<div class="panel-body" >
  	
	<p class="#" style="color:#FFF;font-size:16px"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; There are many parts of problem in which each part has a vital role. It means part is the main entity of the system who interacts with system and does his/her task which is responsibility or role of his/her from starting to the end of the system to complete the process from organize the your events.</strong>
<br /></p>
<h3 style="color:#F3C; text-shadow:#09C 1px 1px 1px"><u>The main entities are following</u>:-</h3>
<h4 style="color:#FFF; text-shadow:#0F0 1px 1px 1px; margin-left:10%"><ol>
<li>Admin</li>
<li>Event Manager</li>
<li>User</li>
</ol></h4>
<p class="#">
    
    <ol style="color:#FFF; font-size:15px">
<li><strong>Admin: -</strong> In our system admin has just rights to maintain the system and listen to teachers and students error reports and even help them in using our system. It is also responsible for system performance and ease of use.</li>
<li><strong>Event Manager:-</strong> They also play a vital role in the system. They manage bookings and serve users. On the basis of service user get from event organize they give their reviews to this site. It event manager in making his/her better events for your demand.</li>
<li><strong> User:-</strong> Users are building block of our website. They can login or register. They will interact the most with the website. They can find best event decoration, catering and venue them and even can book events.</li>
</ol>
    
    </p>
</div>
</div>
<?php include"footer.php"; ?>
</body>
</html>