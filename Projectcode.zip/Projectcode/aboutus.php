<?php include"home.php"; ?>
<br/><br/>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body background="img/ccc.jpg">
<div class="container container-fluid">

	<br />
   <h1 style="color:#FFF; text-shadow:#900 1px 1px 1px;"><center><u> About Us</u></center></h1>
   <h4><a href="slider.php" style="text-decoration:none; color:#FFF">Home </a> <img src="img/back-ar.gif"/><span style="color:#FFF">  About Us</span> </h4>
<div class="panel-body" >
  	
	<p class="#" style="color:#F00;font-size:16px">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Event Organizer Company promoted by Mr. XYZ, who has been in the, Wedding &amp; EventOrganizer from the past 5 years. </font>
<br /><br />	
	<span style="margin-left:10%">We have organized numerous such events, Weddings and parties. We also provide Services to suit your Taste, style, Budget &amp; Requirements. We understands local needs and answers them with good Quality and Choice. We work by heart to help each other to overcome challenges and provide our clients with Professional, Efficient and Courteous service.We believe that Good Business Relationships are forced from Gracious, Honest, Reliable Service and we are proud of the partnerships we have created over the years.&nbsp;  This dream would not have realized without our dear customers, whose love &amp; support have been our pillars of strength, and our inspiration to reach greater heights. As people spend lots of money on Weddings and Parties, but they involve themselves in each and every affair in such a way that at the end of the day they feel that they have not seen the wedding of their only Son/Daughter or they have not been able to enjoy the functions. That&rsquo;s why, a Wedding Planner-Co-ordinator is required to make you, your family &amp; friends comfortable on the day of the Wedding/Event.&nbsp; We as Wedding Planner are here to take care of every thing right from Invitation Cards to Honeymoon Destinations, Theme based Weddings, Musical Extravaganzas and formal Parties and we Organize it all. We make you comfortable to enjoy each and every function along with your family, friends and relatives.We organize for your comfort.&nbsp;
	<br />
	<strong style="margin-left:10%; color:#FFF">We have our own designer invitation cards showroom and we also provide destination marriage services. Our caterers prepare their food in their own modern kitchen and serve hygeinic food at the wedding place.</strong></p>
</div>
</div>
<?php include"footer.php"; ?>
</body>
</html>