<?php
   $host="localhost";
   $user="root";
   $password="";
   $database="online";
   
   
   $con=mysqli_connect($host,$user,$password,$database)or die("Could Not connect To database");


?>