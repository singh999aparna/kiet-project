<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div class="container-fluid" style="background-color:#000">
	<div class="row">
	      <div class="col-sm-4">

    	      <p class="#" style="color:#F96;text-shadow:#FFF 1px 1px 1px; font-size:20px; font-family:Verdana, Geneva, sans-serif">Basic Links</p>
        	  <ul style="color:#FFF"> 
              		<li><a href="slider.php" style="color:#FFF;text-decoration:none">Home</a></li> 
                    <li><a href="aboutus.php"  style="color:#FFF;text-decoration:none">About Us</a>
                    </li> <li><a href="javascript:void(0);" style="text-decoration:none; color:#FFF" data-target="#contactmodal1" data-toggle="modal">Contact Us</a></li>
              </ul>
	      </div><!--Column 1 close-->
      
    	  <div class="col-sm-4">
        	  <p class="#" style="color:#F96;text-shadow:#FFF 1px 1px 1px; font-size:20px; font-family:Verdana, Geneva, sans-serif">Main Navigations</p>
       		   <p class="#">
          		<ul style="color:#FFF"> 
                	<li> <a href="help.php"  style="color:#FFF;text-decoration:none">Help</a></li>
                    <li><a href="cont.php"  style="color:#FFF;text-decoration:none">Events/Party </a></li> 
                    <li><a href="adminlogin.php"  style="color:#FFF;text-decoration:none"> Admin</a></li></p>
                </ul>
          </div><!--Column 2 close-->
      
      
      	<div class="col-sm-4">
        	<p class="#" style="color:#F96;text-shadow:#FFF 1px 1px 1px; font-size:20px; font-family:Verdana, Geneva, sans-serif">Basic Links</p>
        	  <ul style="color:#FFF"> 
              		<li><a href="venue.php" style="color:#FFF;text-decoration:none">Venues</a></li> 
                    <li><a href="decoration.php"  style="color:#FFF;text-decoration:none">Decoration</a>
                    </li> 
                    <li><a href="managerlogin.php" style="text-decoration:none; color:#FFF">Event Manager</a></li>
              </ul>
       </div><!--Column 3 close-->
   </div><!--Row close-->
</div><!--Main close for row-->


<div id="contactmodal1" class="modal fade" role="alertdialog">



   <div class="modal-content" style="background-image:url(img/ccc.jpg); color:#FFF">
   
       <div class="modal-header" style="color:#F96;text-shadow:#333 2px 2px 2px">
          <a href="#contactmodal" data-dismiss="modal" class="close">&times;</a>
          <h1><span class="glyphicon glyphicon-phone"></span>Contact Us</h1>
       </div>
       
       <div class="modal-body">
          <h2><span class="glyphicon glyphicon-user"></span> Anurag	Jain</h2>
          <p><span class="glyphicon glyphicon-phone"></span> Mobile: +91 9997161597, +91 9536230187</p>
          <p><span class="glyphicon glyphicon-phone-alt"></span> Phone: 0121 4023232</p>
          <p><span class="glyphicon glyphicon-envelope"></span> Email: anuragjain7869@gmail.com</p>
          <p><span class="glyphicon glyphicon-plane"></span> Address: Town+Post- Sardhana, Distt- Meerut. [250342]</p>
          
       </div>
   
   </div>
</div>

</body>
</html>